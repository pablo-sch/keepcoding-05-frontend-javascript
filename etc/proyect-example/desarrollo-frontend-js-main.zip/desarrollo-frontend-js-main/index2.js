console.log("hello word desde index2.js")
console.log("a: ", a)

const b = 0;
