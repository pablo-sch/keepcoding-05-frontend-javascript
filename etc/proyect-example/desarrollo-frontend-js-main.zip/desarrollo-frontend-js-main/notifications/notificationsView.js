export const buildNotification = (message) => {
  return `
      <p>${message}</p>
      <button>X</button>
    `
}
