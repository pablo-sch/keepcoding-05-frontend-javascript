export function buildSpinnerView() {
  return `
  <div class="spinner-wrapper hidden">
    <div class="spinner">
      <div></div>
      <div></div>
      <div></div>
      <div></div>
    </div>
  </div>`;
}
